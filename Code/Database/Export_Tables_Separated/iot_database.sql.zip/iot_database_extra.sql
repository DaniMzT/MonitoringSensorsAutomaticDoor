
--
-- Indexes for dumped tables
--

--
-- Indexes for table `alarmsemails_1`
--
ALTER TABLE `alarmsemails_1`
  ADD PRIMARY KEY (`idalarm`);

--
-- Indexes for table `limits_1`
--
ALTER TABLE `limits_1`
  ADD PRIMARY KEY (`idlimit`);

--
-- Indexes for table `testdata_1`
--
ALTER TABLE `testdata_1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alarmsemails_1`
--
ALTER TABLE `alarmsemails_1`
  MODIFY `idalarm` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `limits_1`
--
ALTER TABLE `limits_1`
  MODIFY `idlimit` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testdata_1`
--
ALTER TABLE `testdata_1`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65246;
