
-- --------------------------------------------------------

--
-- Table structure for table `alarmsemails_1`
--

CREATE TABLE `alarmsemails_1` (
  `idalarm` int NOT NULL,
  `Person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `alarmsemails_1`
--

INSERT INTO `alarmsemails_1` (`idalarm`, `Person`, `Email`) VALUES
(1, 'Dani', 'danimartur@gmail.com'),
(4, 'pepito', 'ditomzch@gmail.com');
