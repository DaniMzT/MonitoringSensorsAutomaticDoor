
-- --------------------------------------------------------

--
-- Table structure for table `limits_1`
--

CREATE TABLE `limits_1` (
  `idlimit` int NOT NULL,
  `LimitPos` smallint UNSIGNED NOT NULL DEFAULT '3000',
  `LimitCur` smallint NOT NULL DEFAULT '10000',
  `LimitSp` smallint NOT NULL DEFAULT '1000',
  `LimitTemp` float NOT NULL DEFAULT '100'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `limits_1`
--

INSERT INTO `limits_1` (`idlimit`, `LimitPos`, `LimitCur`, `LimitSp`, `LimitTemp`) VALUES
(1, 30, 10000, 100, 100);
